"""The admin (client) dashboard: overview, search of both profile types, and editing mentors
(US-C01, US-C05, US-C06). Every route here is for admins only; students and mentors get 403."""
from flask import Blueprint, jsonify, request

import validators
from auth_utils import role_required
from constants import MATCH_STATUSES
from database import db
from models import EmailLog, Match, MentorProfile, StudentProfile
from responses import error, json_body
from services import profiles as profile_service
from services.analytics import capacity_summary, feedback_summary, pulse_summary
from services.matching import waiting_students

bp = Blueprint("admin", __name__, url_prefix="/api/admin")


def on_dashboard(mentor):
    """A mentor shows up for the admin once the profile is complete (or when already verified)."""
    return mentor.profile_complete or mentor.profile_status == "verified"


def contains(text, search):
    return search.lower() in (text or "").lower()


@bp.get("/overview")
@role_required("admin")
def overview():
    """Numbers for the dashboard: people, matches by status, and what is waiting."""
    everyone = MentorProfile.query.all()
    mentors = [m for m in everyone if on_dashboard(m)]
    return jsonify({
        "students": StudentProfile.query.count(),
        "mentors": {"total": len(mentors), "verified": sum(m.profile_status == "verified" for m in mentors),
                    "pending": sum(m.profile_status == "pending" for m in mentors),
                    "incomplete": len(everyone) - len(mentors)},
        "matches": {status: Match.query.filter_by(status=status).count() for status in MATCH_STATUSES},
        "students_waiting_for_match": len(waiting_students()),
    })


@bp.get("/analytics")
@role_required("admin")
def analytics():
    """Numbers for the charts: check-in health, feedback ratings and mentor capacity."""
    return jsonify({"pulse": pulse_summary(), "feedback": feedback_summary(), "capacity": capacity_summary()})


@bp.get("/emails")
@role_required("admin")
def email_log():
    """The most recent emails the platform sent (or tried to send). ?limit=50 by default."""
    limit = request.args.get("limit", default=50, type=int)
    if limit < 1:
        return error("limit must be 1 or more.", 400)
    rows = EmailLog.query.order_by(EmailLog.id.desc()).limit(limit).all()
    return jsonify({"emails": [r.to_dict() for r in rows]})


@bp.get("/students")
@role_required("admin")
def list_students():
    """Optional filters: ?search=name or skills, ?topic=Data Science, ?programme_level=Diploma, ?looking=true|false"""
    students = StudentProfile.query.all()
    looking = request.args.get("looking")
    if looking in ("true", "false"):
        students = [s for s in students if s.looking_for_mentor == (looking == "true")]
    search, topic, level = request.args.get("search"), request.args.get("topic"), request.args.get("programme_level")
    if search:
        students = [s for s in students if contains(s.user.full_name, search) or contains(s.skills, search)]
    if topic:
        students = [s for s in students if topic in [t.name for t in s.topics]]
    if level:
        students = [s for s in students if s.programme_level == level]
    return jsonify({"students": [s.to_dict() for s in students]})


@bp.get("/students/<int:student_id>")
@role_required("admin")
def get_student(student_id):
    student = db.session.get(StudentProfile, student_id)
    if student is None:
        return error("Student not found.", 404)
    return jsonify({"profile": student.to_dict()})


@bp.get("/mentors")
@role_required("admin")
def list_mentors():
    """Mentors with a complete profile (and verified ones). Optional filters: ?status=pending|verified, ?topic=Data Science, ?search=name or skills"""
    mentors = [m for m in MentorProfile.query.all() if on_dashboard(m)]
    status, topic, search = request.args.get("status"), request.args.get("topic"), request.args.get("search")
    if status:
        mentors = [m for m in mentors if m.profile_status == status]
    if topic:
        mentors = [m for m in mentors if topic in [t.name for t in m.topics]]
    if search:
        mentors = [m for m in mentors if contains(m.user.full_name, search) or contains(m.skills_text, search)]
    return jsonify({"mentors": [m.to_dict() for m in mentors]})


@bp.get("/mentors/<int:mentor_id>")
@role_required("admin")
def get_mentor(mentor_id):
    mentor = db.session.get(MentorProfile, mentor_id)
    if mentor is None:
        return error("Mentor not found.", 404)
    return jsonify({"profile": mentor.to_dict()})


@bp.put("/mentors/<int:mentor_id>")
@role_required("admin")
def update_mentor(mentor_id):
    """The admin edits a mentor's expertise, skills, experience and capacity (US-C05)."""
    mentor = db.session.get(MentorProfile, mentor_id)
    if mentor is None:
        return error("Mentor not found.", 404)
    problem = profile_service.save_mentor_profile(mentor, json_body())
    if problem:
        return error(problem, 400)
    return jsonify({"profile": mentor.to_dict()})


@bp.patch("/mentors/<int:mentor_id>/status")
@role_required("admin")
def set_mentor_status(mentor_id):
    """Verify a mentor (or put them back to pending)."""
    mentor = db.session.get(MentorProfile, mentor_id)
    if mentor is None:
        return error("Mentor not found.", 404)
    status = (json_body()).get("status")
    problem = validators.check_mentor_status(status)
    if problem:
        return error(problem, 400)
    if status == "verified" and not mentor.profile_complete:
        return error("This mentor has not finished their profile yet.", 409)
    mentor.profile_status = status
    db.session.commit()
    return jsonify({"profile": mentor.to_dict()})


@bp.post("/mentors/<int:mentor_id>/availability")
@role_required("admin")
def add_mentor_slot(mentor_id):
    mentor = db.session.get(MentorProfile, mentor_id)
    if mentor is None:
        return error("Mentor not found.", 404)
    slot, problem = profile_service.add_slot(mentor, json_body())
    if problem:
        return error(problem, 400)
    return jsonify({"slot": slot.to_dict()}), 201


@bp.delete("/mentors/<int:mentor_id>/availability/<int:slot_id>")
@role_required("admin")
def remove_mentor_slot(mentor_id, slot_id):
    mentor = db.session.get(MentorProfile, mentor_id)
    if mentor is None or not profile_service.remove_slot(mentor, slot_id):
        return error("Slot not found.", 404)
    return "", 204
